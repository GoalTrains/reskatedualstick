Dual Stick Controls v6.6 â€” installation

1. Close Skate completely.
2. Open the game folder containing Skate.exe.
3. Back up version.dll and session_controls.ini.
4. Copy the supplied version.dll into that folder, replacing the old mod DLL.
5. Updating from v5.133 or newer: keep your INI. For older installs a fresh session_controls.ini is recommended; back up first, because replacing it resets settings and custom preset slots.
6. Launch normally, press End and choose Session-style or Skater XL-style. Fresh settings start with Session-style.

Manual Catch is OFF by default; enable it under End > Custom > Manual catch. Click L3, R3 or both in the air to catch. Some tricks settle at an angle rather than continuing to rotate; catch timing still matters for a clean result. Missed or mistimed catches can produce an awkward automatic catch. Independent foot catches, dark catches and forced missed-catch bails are not implemented.

Skate handles trick rotation speed; the v6.3 stick-speed override has been removed. Any old GestureSpeed INI key is ignored.

Keep the official ReSkate.dll. Do not replace it with a PR/test runtime.
End opens Dual Stick. Insert opens official ReSkate. D-pad/arrows navigate, A/Enter selects, B goes back, and LB/RB browses diagrams. Hold LB + RB + L3 + R3 for three seconds to toggle Dual Stick. Pumping stays on R3.

Disable hold-fakie is ON by default under Custom. It normally makes Skate's Hold Fakie Stance and Hold Fakie Push read as off without changing saved preferences. Fresh held manual/setup input temporarily enables effective Hold Fakie Stance to defer normalization; release restores the compatibility override. Automatic pose resets and heavy diagnostics are OFF.

If keeping an old INI, reapply your preferred preset and set these under [SessionControls]:
DisableHoldFakie=1
NativeMenuRespawnRecovery=0
NativeGroundPoseRecovery=0
SteerCurvePercent=100

Windows controllers
PlayStationPads=1 reads supported PlayStation pads and presents Xbox input. For native DualSense use PlayStationPads=2, disable Steam Input and restart. If Steam Input, DS4Windows or DSX supplies Xbox input, use PlayStationPads=0.

FOOT SETUP grind controls are enabled in fresh settings. If keeping your INI, enable Custom > Grind setup > FOOT SETUP (SplitGrindControls=1). For dedicated two-foot setup, block single-stick flips.

Optional Windows updater (separate zip)
Copy DualStickLauncher.exe, dual_stick_updater.json and the updater folder beside ReSkateLauncher.exe. Keep an existing updater JSON to retain your preferences. Open DualStickLauncher.exe (or create a ReSkate + Dual Stick shortcut) for future launches. It shows patch notes and asks before updating. Skip this release keeps your build until a newer release; Disable update checks stops checks; closing the window skips this launch. The official ReSkate files and updater settings are untouched.

D-pad camera sides is ON by default: tap left/right to select a side, hold 0.5 seconds for the original action. The mod applies the required camera settings and keeps L3 available to its other controls. Turn it off under End > Custom if desired. An existing DpadCameraSide=0 is respected.


v6.6 - Grind entry and foot controls
Changes since v6.5

- Fixes a pop-to-air timing issue that could turn a sideways foot setup into another ground gesture before takeoff. This targets inconsistent frontside tailslide entries and unexpected board rotation after the pop.
- Applies the handoff to flick pops and release pops, including ollies and nollies. Release pops keep their full pop pulse, and stick steering no longer consumes the pending foot setup.
- Corrects back-foot circular adjustments on a rail: circling the rear stick rotates in the same angular direction as front-foot circles, while preserving the initial entry pose and analog strength.
- Keeps held sideways foot setups consistent through brief ground contact before a rail, instead of restarting them as a fresh ground flick or reversing the setup.
- Recognizes Skate's additional native grind state, preventing controls from dropping out or switching to ground handling during that part of a grind.
- Improves Left/Right Foot stance tracking by sharing the native physical-foot checks already used by XL/True Foot. Front/Back Foot keeps its separate role mapping.
- Keeps the experimental native grind-target/alignment override disabled by default. Skate still chooses contact and lock-in.

Setup and updating
The post-pop handoff and rear-foot circular adjustment fixes apply with FOOT SETUP enabled, Air controls on, and single-stick flips BLOCKED. ALLOWED single-stick flips and other grind modes retain their existing behavior.

Close Skate and replace version.dll beside Skate.exe. Keep your existing session_controls.ini and official ReSkate.dll. For a fresh install, use the included settings. Enable End > Custom > Grind setup > FOOT SETUP and block single-stick flips for dedicated two-foot positioning. Existing presets and Manual Catch preferences are preserved.

Validation and remaining limits
All 118 automated control regression programs pass, including 36,864 setup/pop combinations covering regular/goofy, normal/switch, swapped feet, switch modes, custom axis directions, both pop styles and stick steering. A replay of 22,166 recorded inputs produces identical output to the improved dev11 baseline for the tested flick-pop setup. Windows DLL loading and version forwarding pass; the packaged updater migration is checked separately.

Local gameplay feedback reports improved grind feel. These checks do not guarantee every grind choice or every controller/setup in game. Skate's native contact/assist behavior can still change the resulting grind. Manual Catch behavior and its existing limitations are unchanged.

Linux / Steam Deck uses the Windows DLL under Proton with WINEDLLOVERRIDES="version=n,b" %command%. This release has not been gameplay-tested on Linux/Steam Deck. macOS compatibility is unverified.
