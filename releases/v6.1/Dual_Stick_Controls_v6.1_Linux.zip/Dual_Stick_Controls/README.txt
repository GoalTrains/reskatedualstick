Dual Stick Controls v6.1 — installation

1. Close Skate completely.
2. Open the game folder containing Skate.exe.
3. Back up version.dll and session_controls.ini.
4. Copy version.dll from this folder beside Skate.exe, replacing the old mod DLL.
5. Keep an existing INI from v5.133 or newer. For older versions, back it up before replacing it with this fresh settings file.
6. Keep the official ReSkate.dll. Press End in game to open Dual Stick settings.

Manual catch (early attempt) is OFF by default. To try it, open Custom > Manual catch (early attempt). Many flip, scoop and combo tricks may still fail to hold; disable it if it interferes.

The full changes and known limitations are in CHANGELOG.txt. Windows and Linux packages include the mod DLL and fresh settings. On Linux/Steam Deck with Proton, use launch option:
WINEDLLOVERRIDES="version=n,b" %command%